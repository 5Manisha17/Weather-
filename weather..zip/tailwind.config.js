module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx}",//Adjusted to include all files in src
  "./pages/**.{js,ts,jsx,tsx}",
"./components/**/*.{js,ts,jsx,tsx}"
 ],
 // darkMode: false, // or 'media' or 'class'
  theme: {
    extend: {},
  },
  plugins: [],
}
